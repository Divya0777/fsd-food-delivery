Free Download Source Code "Online Food Ordering System"

FIRST Download

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3"Online_Food_Ordering_System"

4. Download the zip file/ download winrar

5. Extract the file and copy "Online_Food_Ordering_System" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name fos_db

6. Import fos_db.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Online_Food_Ordering_System


**LOGIN DETAILS** 

Admin
user: admin
pass: admin123

****** www.campcodes.com ******
Subcribe to our Youtube Channel **** CampCodes ****